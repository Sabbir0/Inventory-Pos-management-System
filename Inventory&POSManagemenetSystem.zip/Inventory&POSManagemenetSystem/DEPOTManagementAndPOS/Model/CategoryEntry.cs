﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEPOTManagementAndPOS.Model
{
    class CategoryEntry
    {
        public int CategoryEntryId { get; set; }
        public string Name { get; set; }

    }
}
