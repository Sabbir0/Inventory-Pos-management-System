﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEPOTManagementAndPOS.UI
{
    public partial class StartUpUi : Form
    {
        public StartUpUi()
        {
            InitializeComponent();
        }
        String id = "admin";
        String password ="admin7400";
        private void loginButton_Click(object sender, EventArgs e)
        {

            Login();



        }

        private void Login()
        {
            if (!String.IsNullOrEmpty(LoginIdTextBox.Text) && !String.IsNullOrEmpty(passwordTextBox.Text))
            {


                if (LoginIdTextBox.Text == id && passwordTextBox.Text == password)
                {
                    this.Hide();
                    SellProductUi aSellProductUi = new SellProductUi();
                    aSellProductUi.ShowDialog();


                }
                else
                {
                    MessageBox.Show("Sorry !! You are Not Actual User/Incorrect Entry !!!");
                }


            }
        }

        private void loginButton_KeyPress(object sender, KeyPressEventArgs e)
        {
            Login();
        }

       

     
    }
}
