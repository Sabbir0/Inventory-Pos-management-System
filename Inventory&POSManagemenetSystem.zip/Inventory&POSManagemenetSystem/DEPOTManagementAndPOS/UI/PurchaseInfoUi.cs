﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DEPOTManagementAndPOS.BLL;
using DEPOTManagementAndPOS.Model;

namespace DEPOTManagementAndPOS.UI
{
    public partial class PurchaseInfoUi : Form
    {
        public PurchaseInfoUi()
        {
            InitializeComponent();
            LoadPurchaseInformation();
        }

        private void LoadPurchaseInformation()
        {
           PurchaseManager aPurchaseManager=new PurchaseManager();
            List<Purchase> aPurchasesList=new List<Purchase>();
            aPurchasesList = aPurchaseManager.GetPurchaseInfo();
            foreach (var purchaseList in aPurchasesList)
            {
                purchaseInformationGridView.Rows.Add(purchaseList.ProductName,
                    purchaseList.Quantity,purchaseList.Price,purchaseList.TotalPurchasePrice);
                
            }
            
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveToExcelbutton_Click(object sender, EventArgs e)
        {


             Microsoft.Office.Interop.Excel.Application xlApp;
            Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            Int16 i, j;
            
            xlApp = new Microsoft.Office.Interop.Excel.ApplicationClass();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            Microsoft.Office.Interop.Excel.Range chartRange;

            xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            xlApp.Columns.ColumnWidth = 15;
            xlWorkSheet.get_Range("A1", "D1").Merge(false);

            chartRange = xlWorkSheet.get_Range("A1", "D1");
            chartRange.FormulaR1C1 = "** GOLDEN INSPIRE **  Jessore 7400 ";
            chartRange.HorizontalAlignment = 3;
            chartRange.VerticalAlignment = 3;
            xlWorkSheet.get_Range("A2", "D2").Merge(false);
            chartRange = xlWorkSheet.get_Range("A2", "D2");
            chartRange.FormulaR1C1 = "Jessore 7400 ";
            chartRange.HorizontalAlignment = 3;
            chartRange.VerticalAlignment = 3;

            chartRange = xlWorkSheet.get_Range("A1", "D1");
            chartRange.Font.Bold = true;
            
            chartRange = xlWorkSheet.get_Range("A5", "D5");
            
            chartRange.Font.Bold = true;



            for (int c = 1; c < purchaseInformationGridView.Columns.Count + 1; c++)
            {

                xlApp.Cells[5, c] = purchaseInformationGridView.Columns[c - 1].HeaderText;

            }

            for (i = 0; i <= purchaseInformationGridView.RowCount - 2; i++)
            {
                for (j = 0; j <= purchaseInformationGridView.ColumnCount - 1; j++)
                {
                    xlWorkSheet.Cells[i + 6, j + 1] = purchaseInformationGridView[j, i].Value.ToString();
                }
            }

            xlWorkBook.SaveAs(@"C:\Users\Public\Purchase Report.xls",
                Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, 
                Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);
            




        }
        
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }


      



        

      
    }
}
