﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using DEPOTManagementAndPOS.BLL;
using DEPOTManagementAndPOS.Model;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Org.BouncyCastle.Asn1.Microsoft;
using Rectangle = iTextSharp.text.Rectangle;
using System.Text.RegularExpressions;
using Excel = Microsoft.Office.Interop.Excel; 


namespace DEPOTManagementAndPOS.UI
{
    public partial class DailySellReportUi : Form
    {
        public DailySellReportUi()
        {
            InitializeComponent();
        }

        private void showDailyReportButton_Click(object sender, EventArgs e)
        {
            dailySellReportDataGridView.Rows.Clear();
            string selectedDate = sellReportDateTimePicker.Value.ToShortDateString();

            List<SellInvoice> _sellInvoiceList = new List<SellInvoice>();
            SellInvoiceManager _aSellInvoiceManager = new SellInvoiceManager();
            _sellInvoiceList = _aSellInvoiceManager.GetSellReportUsingDate(selectedDate);

            double totalAmountOfMoneyInADay = 0;
            foreach (var sellInvoice in _sellInvoiceList)
            {
                dailySellReportDataGridView.Rows.Add(sellInvoice.OrderNo, sellInvoice.SellDate, sellInvoice.Customer.Name,
                    sellInvoice.GrandTotal, sellInvoice.Paid, sellInvoice.Due,
                    sellInvoice.TotalItemSold, sellInvoice.CashStatus);
                totalAmountOfMoneyInADay += sellInvoice.GrandTotal;

            }

            totalAmountOfMoneySoldTextBox.Text = totalAmountOfMoneyInADay.ToString();

        }

        private void showPDFReportButton_Click(object sender, EventArgs e)
        {
            iTextSharp.text.Rectangle rec2 = new iTextSharp.text.Rectangle(PageSize.A4);

            rec2.BackgroundColor = new CMYKColor(0, 0, 0, 0);

            //string appRootDir = new DirectoryInfo(Environment.CurrentDirectory).Parent.Parent.FullName;
            string appRootDir = @"C:\Users\Public\Documents";
            try
            {
                String Date = sellReportDateTimePicker.Text;
                using (FileStream fs = new FileStream(appRootDir+ "DailyReportFor"+Date+".csv", FileMode.Create, FileAccess.Write, FileShare.None))
                
                using (Document doc = new Document(rec2))
                using (PdfWriter writer = PdfWriter.GetInstance(doc, fs))
                {
                    
                    doc.Open();

                    PdfPTable reportTable = new PdfPTable(dailySellReportDataGridView.Columns.Count);

                    for (int i = 0; i < dailySellReportDataGridView.Columns.Count; i++)
                    {
                        reportTable.AddCell(new Phrase(dailySellReportDataGridView.Columns[i].HeaderText));
                    }

                    reportTable.HeaderRows = 1;

                    for (int j = 0; j < dailySellReportDataGridView.Rows.Count; j++)
                    {
                        for (int k = 0; k < dailySellReportDataGridView.Columns.Count; k++)
                        {
                            if (dailySellReportDataGridView[k, j].Value != null)
                            {
                                reportTable.AddCell(new Phrase(dailySellReportDataGridView[k, j].Value.ToString()));
                            }
                        }
                    }

                    doc.Add(reportTable);
                    doc.Close();

                    System.Diagnostics.Process.Start(appRootDir + "DailyReportFor" + Date + ".csv");

                }
            }
            
            catch (DocumentException de)
            {
                throw de;
            }
            
            catch (IOException ioe)
            {
                throw ioe;
            }
        }

     

    
        private void saveToExelButton_Click(object sender, EventArgs e)
        {
           
       

            //SaveFileDialog aFileDialog=new SaveFileDialog();
            //aFileDialog.InitialDirectory = "C:";
            //aFileDialog.Title = "Save As Excel Fie";
            //aFileDialog.FileName = "";
            //aFileDialog.Filter = "Excel Files(2003)|*.xls|Excel Files(2007)|*.xlsx";
            //if (aFileDialog.ShowDialog() != DialogResult.Cancel)
            //{
            //    Microsoft.Office.Interop.Excel.ApplicationClass ExcelApp;
            //    ExcelApp =new Microsoft.Office.Interop.Excel.ApplicationClass();
            //    ExcelApp.Application.Workbooks.Add(Type.Missing);
            //    //Property WorkBook;
            //    ExcelApp.Columns.ColumnWidth = 20;

            //    for (int i=1;i<dailySellReportDataGridView.Columns.Count+1;i++)
            //    {
                    
            //        ExcelApp.Cells[1, i] = dailySellReportDataGridView.Columns[i - 1].HeaderText;

            //    }
            //    for (int i = 0; i < dailySellReportDataGridView.Rows.Count; i++)
            //    {
            //        for (int j = 0; j < dailySellReportDataGridView.Columns.Count; j++)
            //        {
            //            ExcelApp.Cells[i+2, j+1] = dailySellReportDataGridView.Rows[i].Cells[j].Value.ToString();
            //        }
            //    }

            //    ExcelApp.ActiveWorkbook.SaveCopyAs(aFileDialog.FileName.ToString());
            //    ExcelApp.ActiveWorkbook.Saved = true;
            //    ExcelApp.Quit();
            //}

            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            Int16 i, j;
            string date = sellReportDateTimePicker.Text;
            xlApp = new Excel.ApplicationClass();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            Excel.Range chartRange;

            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            xlApp.Columns.ColumnWidth = 20;
            xlWorkSheet.get_Range("A1", "H1").Merge(false);

            chartRange = xlWorkSheet.get_Range("A1", "H1");
            chartRange.FormulaR1C1 = "** GOLDEN INSPIRE **  Jessore 7400 ";
            chartRange.HorizontalAlignment = 3;
            chartRange.VerticalAlignment = 3;
            xlWorkSheet.get_Range("A2", "H2").Merge(false);
            chartRange = xlWorkSheet.get_Range("A2", "H2");
            chartRange.FormulaR1C1 = "Jessore 7400 ";
            chartRange.HorizontalAlignment = 3;
            chartRange.VerticalAlignment = 3;

            chartRange = xlWorkSheet.get_Range("A1", "H1");
            chartRange.Font.Bold = true;
            
            chartRange = xlWorkSheet.get_Range("A5", "H5");
            
            chartRange.Font.Bold = true;
            

           
            for (int c = 1; c < dailySellReportDataGridView.Columns.Count + 1; c++)
            {

                xlApp.Cells[5, c] = dailySellReportDataGridView.Columns[c - 1].HeaderText;

            }
            
            for (i = 0; i <= dailySellReportDataGridView.RowCount - 2; i++)
            {
                for (j = 0; j <= dailySellReportDataGridView.ColumnCount - 1; j++)
                {
                    xlWorkSheet.Cells[i + 6, j + 1] = dailySellReportDataGridView[j, i].Value.ToString();
                }
            }

            xlWorkBook.SaveAs(@"C:\Users\Public\" + date + "Daily Sell Report.xls",
                Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, 
                Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);
            




        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

      

        
        
    }
}
